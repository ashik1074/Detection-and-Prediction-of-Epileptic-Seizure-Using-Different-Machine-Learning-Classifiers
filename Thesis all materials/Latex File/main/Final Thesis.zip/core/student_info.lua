student_1 = {}
student_1["id"] = "21141046"
student_1["name"] = "Afnan Ahmed Crystal"

student_2 = {}
student_2["id"] = "18101512"
student_2["name"] = "Nuna Tasnim"

student_3 = {}
student_3["id"] = "18101636"
student_3["name"] = "Subha Sumaiya B Jamal"

student_4 = {}
student_4["id"] = "18101074"
student_4["name"] = "Md. Ashikur Rahman"


--Mention the number of students in the group
number_of_students = 4